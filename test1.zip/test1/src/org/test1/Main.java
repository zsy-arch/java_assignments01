package org.test1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.test1.WebServer.SocketHandler;

public class Main {
	private static String wwwRoot;

	public static void main(String[] args) {
		wwwRoot = "d:/wwwroot/";
		
		SocketHandler socketHandler = new SocketHandler((s) -> {
			System.out.println("accept");
			try {
				FileInputStream fis = new FileInputStream(wwwRoot + "/index.html");
				byte[] fileBytes = fis.readAllBytes();
				String header = "HTTP/1.1 200 OK\n\n";
				s.getOutputStream().write(header.getBytes());
				s.getOutputStream().write(fileBytes);
				fis.close();
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		WebServer webServer = new WebServer(18080, socketHandler);
		new Thread(webServer).start();
	}
}
