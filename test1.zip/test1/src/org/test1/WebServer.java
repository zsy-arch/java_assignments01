package org.test1;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class WebServer implements Runnable {
	
	public interface SocketDoer {
		void doSomething(Socket s);
	}
	
	public static class SocketHandler implements Runnable {
		Socket socket;
		SocketDoer socketDoer;
		
		public SocketHandler(SocketDoer socketDoer) {
			super();
			this.socketDoer = socketDoer;
		}

		public Socket getSocket() {
			return socket;
		}

		public void setSocket(Socket socket) {
			this.socket = socket;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				socketDoer.doSomething(socket);				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	private int port;
	private SocketHandler socketHandler;

	public WebServer(int port, SocketHandler socketHandler) {
		super();
		this.port = port;
		this.socketHandler = socketHandler;
	}

	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(port);
			while (!serverSocket.isClosed()) {
				Socket client = serverSocket.accept();
				if (!client.isClosed()) {
					socketHandler.setSocket(client);
					new Thread(socketHandler).start();
				}
			}
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
